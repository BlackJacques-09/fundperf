# FundPerformance

This package allows you to calculate a panel of performance indicators.

## Installation Process

# STATUS // Under construction :construction:

## Examples

# STATUS // Under construction :construction:
